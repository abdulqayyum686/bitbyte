import React, { useState } from "react";
import Book from "@/components/Book";

const Shelf = ({ title, books }) => {
  const [sortOrder, setSortOrder] = useState("asc"); // 'asc' for ascending, 'desc' for descending

  const sortBooks = (books) => {
    return books.sort((a, b) => {
      const titleA = a.title.toUpperCase(); // ignore upper and lowercase
      const titleB = b.title.toUpperCase(); // ignore upper and lowercase
      if (sortOrder === "asc") {
        return titleA < titleB ? -1 : titleA > titleB ? 1 : 0;
      } else {
        return titleA > titleB ? -1 : titleA < titleB ? 1 : 0;
      }
    });
  };

  const toggleSortOrder = () => {
    setSortOrder((prevOrder) => (prevOrder === "asc" ? "desc" : "asc"));
  };

  const sortedBooks = sortBooks([...books]);

  return (
    <>
      <div>
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-bold">{title}</h2>
          {sortedBooks.length > 0 && (
            <button
              className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-700 transition duration-300"
              onClick={toggleSortOrder}
            >
              Sort {sortOrder === "asc" ? "Descending" : "Ascending"}
            </button>
          )}
        </div>
        <div className="grid grid-cols-3 gap-4">
          {sortedBooks.length > 0 ? (
            sortedBooks.map((book) => <Book key={book.id} book={book} />)
          ) : (
            <div>No book available</div>
          )}
        </div>
      </div>
    </>
  );
};

export default Shelf;
