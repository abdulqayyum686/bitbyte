import React from "react";

const Book = ({ book }) => {
  return (
    <>
      <div className="bg-white shadow-md rounded p-4">
        <h2 className="text-lg font-bold">{book.title}</h2>
        <p>{book.authorName}</p>
        <p>{book.publicationHouse}</p>
        <p>{book.publicationDate}</p>
        <p>{book.Genre}</p>
        <p>{book.type}</p>
      </div>
    </>
  );
};

export default Book;
