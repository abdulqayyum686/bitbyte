"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/user/register";
exports.ids = ["pages/api/user/register"];
exports.modules = {

/***/ "bcrypt":
/*!*************************!*\
  !*** external "bcrypt" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("bcrypt");

/***/ }),

/***/ "mongoose":
/*!***************************!*\
  !*** external "mongoose" ***!
  \***************************/
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ "(api)/./config/dbConnect.js":
/*!*****************************!*\
  !*** ./config/dbConnect.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mongoose */ \"mongoose\");\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);\n\nconst MONGO_URL = process.env.DATABASE_URI;\nif (!MONGO_URL) {\n    throw new Error(\"Please define the MONGO_URL environment variable inside .env.local\");\n}\nconsole.log(MONGO_URL);\nasync function dbConnect() {\n    const con = await mongoose__WEBPACK_IMPORTED_MODULE_0___default().connect(MONGO_URL);\n    return con;\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (dbConnect);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9jb25maWcvZGJDb25uZWN0LmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7OztBQUFnQztBQUNoQyxNQUFNQyxZQUFZQyxRQUFRQyxHQUFHLENBQUNDLFlBQVk7QUFFMUMsSUFBSSxDQUFDSCxXQUFXO0lBQ2QsTUFBTSxJQUFJSSxNQUNSLHNFQUNBO0FBQ0osQ0FBQztBQUNEQyxRQUFRQyxHQUFHLENBQUNOO0FBQ1osZUFBZU8sWUFBWTtJQUN6QixNQUFNQyxNQUFNLE1BQU1ULHVEQUFnQixDQUNoQ0M7SUFFRixPQUFPUTtBQUNUO0FBRUEsaUVBQWVELFNBQVNBLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9ib29rc2xpYnJhcnkvLi9jb25maWcvZGJDb25uZWN0LmpzPzc3OWEiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IG1vbmdvb3NlIGZyb20gXCJtb25nb29zZVwiO1xyXG5jb25zdCBNT05HT19VUkwgPSBwcm9jZXNzLmVudi5EQVRBQkFTRV9VUkk7XHJcblxyXG5pZiAoIU1PTkdPX1VSTCkge1xyXG4gIHRocm93IG5ldyBFcnJvcihcclxuICAgIFwiUGxlYXNlIGRlZmluZSB0aGUgTU9OR09fVVJMIGVudmlyb25tZW50IHZhcmlhYmxlIGluc2lkZSAuZW52LmxvY2FsXCJcclxuICApO1xyXG59XHJcbmNvbnNvbGUubG9nKE1PTkdPX1VSTCk7XHJcbmFzeW5jIGZ1bmN0aW9uIGRiQ29ubmVjdCgpIHtcclxuICBjb25zdCBjb24gPSBhd2FpdCBtb25nb29zZS5jb25uZWN0KFxyXG4gICAgTU9OR09fVVJMXHJcbiAgKTtcclxuICByZXR1cm4gY29uO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBkYkNvbm5lY3Q7XHJcbiJdLCJuYW1lcyI6WyJtb25nb29zZSIsIk1PTkdPX1VSTCIsInByb2Nlc3MiLCJlbnYiLCJEQVRBQkFTRV9VUkkiLCJFcnJvciIsImNvbnNvbGUiLCJsb2ciLCJkYkNvbm5lY3QiLCJjb24iLCJjb25uZWN0Il0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./config/dbConnect.js\n");

/***/ }),

/***/ "(api)/./models/User.js":
/*!************************!*\
  !*** ./models/User.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mongoose */ \"mongoose\");\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);\n\nconst userSchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({\n    userName: {\n        type: String,\n        required: true\n    },\n    email: {\n        type: String,\n        required: true\n    },\n    password: String\n}, {\n    timestamps: true\n});\nif ((mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.User)) {\n    delete (mongoose__WEBPACK_IMPORTED_MODULE_0___default().connection.models.User);\n}\nconst userModel = mongoose__WEBPACK_IMPORTED_MODULE_0___default().model(\"User\", userSchema);\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (userModel);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9tb2RlbHMvVXNlci5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7QUFBZ0M7QUFFaEMsTUFBTUMsYUFBYSxJQUFJRCx3REFBZSxDQUNwQztJQUNFRyxVQUFVO1FBQ1JDLE1BQU1DO1FBQ05DLFVBQVUsSUFBSTtJQUNoQjtJQUNBQyxPQUFPO1FBQ0xILE1BQU1DO1FBQ05DLFVBQVUsSUFBSTtJQUNoQjtJQUNBRSxVQUFVSDtBQUNaLEdBQ0E7SUFDRUksWUFBWSxJQUFJO0FBQ2xCO0FBR0YsSUFBSVQsNkRBQW9CLEVBQUU7SUFDeEIsT0FBT0Esd0VBQWtDO0FBQzNDLENBQUM7QUFFRCxNQUFNYSxZQUFZYixxREFBYyxDQUFDLFFBQVFDO0FBRXpDLGlFQUFlWSxTQUFTQSxFQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vYm9va3NsaWJyYXJ5Ly4vbW9kZWxzL1VzZXIuanM/NzM2NyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgbW9uZ29vc2UgZnJvbSBcIm1vbmdvb3NlXCI7XHJcblxyXG5jb25zdCB1c2VyU2NoZW1hID0gbmV3IG1vbmdvb3NlLlNjaGVtYShcclxuICB7XHJcbiAgICB1c2VyTmFtZToge1xyXG4gICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgIHJlcXVpcmVkOiB0cnVlLFxyXG4gICAgfSxcclxuICAgIGVtYWlsOiB7XHJcbiAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgcmVxdWlyZWQ6IHRydWUsXHJcbiAgICB9LFxyXG4gICAgcGFzc3dvcmQ6IFN0cmluZyxcclxuICB9LFxyXG4gIHtcclxuICAgIHRpbWVzdGFtcHM6IHRydWUsXHJcbiAgfVxyXG4pO1xyXG5cclxuaWYgKG1vbmdvb3NlLm1vZGVscy5Vc2VyKSB7XHJcbiAgZGVsZXRlIG1vbmdvb3NlLmNvbm5lY3Rpb24ubW9kZWxzW1wiVXNlclwiXTtcclxufVxyXG5cclxuY29uc3QgdXNlck1vZGVsID0gbW9uZ29vc2UubW9kZWwoXCJVc2VyXCIsIHVzZXJTY2hlbWEpO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgdXNlck1vZGVsO1xyXG4iXSwibmFtZXMiOlsibW9uZ29vc2UiLCJ1c2VyU2NoZW1hIiwiU2NoZW1hIiwidXNlck5hbWUiLCJ0eXBlIiwiU3RyaW5nIiwicmVxdWlyZWQiLCJlbWFpbCIsInBhc3N3b3JkIiwidGltZXN0YW1wcyIsIm1vZGVscyIsIlVzZXIiLCJjb25uZWN0aW9uIiwidXNlck1vZGVsIiwibW9kZWwiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./models/User.js\n");

/***/ }),

/***/ "(api)/./pages/api/user/register.js":
/*!************************************!*\
  !*** ./pages/api/user/register.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _models_User__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../models/User */ \"(api)/./models/User.js\");\n/* harmony import */ var bcrypt__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! bcrypt */ \"bcrypt\");\n/* harmony import */ var bcrypt__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(bcrypt__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _config_dbConnect__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../config/dbConnect */ \"(api)/./config/dbConnect.js\");\n\n\n\nconst registerController = async (req, res)=>{\n    console.log(req.body);\n    await (0,_config_dbConnect__WEBPACK_IMPORTED_MODULE_2__[\"default\"])();\n    if (req.method === \"POST\") {\n        const { userName , email , password  } = req.body;\n        if (!email || !password || !userName) {\n            return res.status(406).json({\n                message: \"Some Fields are missing\"\n            });\n        }\n        try {\n            const isEmailExists = await _models_User__WEBPACK_IMPORTED_MODULE_0__[\"default\"].findOne({\n                email\n            }).exec();\n            if (isEmailExists) {\n                return res.status(406).json({\n                    message: \"Email Already Exists\"\n                });\n            }\n            const hashedPassword = await bcrypt__WEBPACK_IMPORTED_MODULE_1___default().hash(password, 10);\n            const newUser = new _models_User__WEBPACK_IMPORTED_MODULE_0__[\"default\"]({\n                email,\n                password: hashedPassword,\n                userName\n            });\n            let result = await newUser.save();\n            res.status(201).json({\n                message: \"New User has been created successfully!\",\n                result\n            });\n        } catch (err) {\n            console.log(err);\n            res.status(500).json({\n                message: \"Something went Wrong, Internal Server Error!\"\n            });\n        }\n    } else {\n        return res.status(404).json({\n            message: \"Invalid Request Method\"\n        });\n    }\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (registerController);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvdXNlci9yZWdpc3Rlci5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUF3QztBQUNaO0FBQ3NCO0FBQ2xELE1BQU1HLHFCQUFxQixPQUFPQyxLQUFLQyxNQUFRO0lBQzdDQyxRQUFRQyxHQUFHLENBQUNILElBQUlJLElBQUk7SUFDcEIsTUFBTU4sNkRBQVNBO0lBRWYsSUFBSUUsSUFBSUssTUFBTSxLQUFLLFFBQVE7UUFDekIsTUFBTSxFQUFFQyxTQUFRLEVBQUVDLE1BQUssRUFBRUMsU0FBUSxFQUFFLEdBQUdSLElBQUlJLElBQUk7UUFDOUMsSUFBSSxDQUFDRyxTQUFTLENBQUNDLFlBQVksQ0FBQ0YsVUFBVTtZQUNwQyxPQUFPTCxJQUFJUSxNQUFNLENBQUMsS0FBS0MsSUFBSSxDQUFDO2dCQUMxQkMsU0FBUztZQUNYO1FBQ0YsQ0FBQztRQUVELElBQUk7WUFDRixNQUFNQyxnQkFBZ0IsTUFBTWhCLDREQUFZLENBQUM7Z0JBQUVXO1lBQU0sR0FBR08sSUFBSTtZQUV4RCxJQUFJRixlQUFlO2dCQUNqQixPQUFPWCxJQUFJUSxNQUFNLENBQUMsS0FBS0MsSUFBSSxDQUFDO29CQUMxQkMsU0FBUztnQkFDWDtZQUNGLENBQUM7WUFDRCxNQUFNSSxpQkFBaUIsTUFBTWxCLGtEQUFXLENBQUNXLFVBQVU7WUFDbkQsTUFBTVMsVUFBVSxJQUFJckIsb0RBQUlBLENBQUM7Z0JBQ3ZCVztnQkFDQUMsVUFBVU87Z0JBQ1ZUO1lBQ0Y7WUFDQSxJQUFJWSxTQUFTLE1BQU1ELFFBQVFFLElBQUk7WUFDL0JsQixJQUFJUSxNQUFNLENBQUMsS0FBS0MsSUFBSSxDQUFDO2dCQUNuQkMsU0FBUztnQkFDVE87WUFDRjtRQUNGLEVBQUUsT0FBT0UsS0FBSztZQUNabEIsUUFBUUMsR0FBRyxDQUFDaUI7WUFDWm5CLElBQUlRLE1BQU0sQ0FBQyxLQUFLQyxJQUFJLENBQUM7Z0JBQ25CQyxTQUFTO1lBQ1g7UUFDRjtJQUNGLE9BQU87UUFDTCxPQUFPVixJQUFJUSxNQUFNLENBQUMsS0FBS0MsSUFBSSxDQUFDO1lBQUVDLFNBQVM7UUFBeUI7SUFDbEUsQ0FBQztBQUNIO0FBRUEsaUVBQWVaLGtCQUFrQkEsRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2Jvb2tzbGlicmFyeS8uL3BhZ2VzL2FwaS91c2VyL3JlZ2lzdGVyLmpzP2M4ZmUiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFVzZXIgZnJvbSBcIi4uLy4uLy4uL21vZGVscy9Vc2VyXCI7XHJcbmltcG9ydCBiY3J5cHQgZnJvbSBcImJjcnlwdFwiO1xyXG5pbXBvcnQgZGJDb25uZWN0IGZyb20gXCIuLi8uLi8uLi9jb25maWcvZGJDb25uZWN0XCI7XHJcbmNvbnN0IHJlZ2lzdGVyQ29udHJvbGxlciA9IGFzeW5jIChyZXEsIHJlcykgPT4ge1xyXG4gIGNvbnNvbGUubG9nKHJlcS5ib2R5KTtcclxuICBhd2FpdCBkYkNvbm5lY3QoKTtcclxuXHJcbiAgaWYgKHJlcS5tZXRob2QgPT09IFwiUE9TVFwiKSB7XHJcbiAgICBjb25zdCB7IHVzZXJOYW1lLCBlbWFpbCwgcGFzc3dvcmQgfSA9IHJlcS5ib2R5O1xyXG4gICAgaWYgKCFlbWFpbCB8fCAhcGFzc3dvcmQgfHwgIXVzZXJOYW1lKSB7XHJcbiAgICAgIHJldHVybiByZXMuc3RhdHVzKDQwNikuanNvbih7XHJcbiAgICAgICAgbWVzc2FnZTogXCJTb21lIEZpZWxkcyBhcmUgbWlzc2luZ1wiLFxyXG4gICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBpc0VtYWlsRXhpc3RzID0gYXdhaXQgVXNlci5maW5kT25lKHsgZW1haWwgfSkuZXhlYygpO1xyXG5cclxuICAgICAgaWYgKGlzRW1haWxFeGlzdHMpIHtcclxuICAgICAgICByZXR1cm4gcmVzLnN0YXR1cyg0MDYpLmpzb24oe1xyXG4gICAgICAgICAgbWVzc2FnZTogXCJFbWFpbCBBbHJlYWR5IEV4aXN0c1wiLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICAgIGNvbnN0IGhhc2hlZFBhc3N3b3JkID0gYXdhaXQgYmNyeXB0Lmhhc2gocGFzc3dvcmQsIDEwKTtcclxuICAgICAgY29uc3QgbmV3VXNlciA9IG5ldyBVc2VyKHtcclxuICAgICAgICBlbWFpbCxcclxuICAgICAgICBwYXNzd29yZDogaGFzaGVkUGFzc3dvcmQsXHJcbiAgICAgICAgdXNlck5hbWUsXHJcbiAgICAgIH0pO1xyXG4gICAgICBsZXQgcmVzdWx0ID0gYXdhaXQgbmV3VXNlci5zYXZlKCk7XHJcbiAgICAgIHJlcy5zdGF0dXMoMjAxKS5qc29uKHtcclxuICAgICAgICBtZXNzYWdlOiBcIk5ldyBVc2VyIGhhcyBiZWVuIGNyZWF0ZWQgc3VjY2Vzc2Z1bGx5IVwiLFxyXG4gICAgICAgIHJlc3VsdCxcclxuICAgICAgfSk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5sb2coZXJyKTtcclxuICAgICAgcmVzLnN0YXR1cyg1MDApLmpzb24oe1xyXG4gICAgICAgIG1lc3NhZ2U6IFwiU29tZXRoaW5nIHdlbnQgV3JvbmcsIEludGVybmFsIFNlcnZlciBFcnJvciFcIixcclxuICAgICAgfSk7XHJcbiAgICB9XHJcbiAgfSBlbHNlIHtcclxuICAgIHJldHVybiByZXMuc3RhdHVzKDQwNCkuanNvbih7IG1lc3NhZ2U6IFwiSW52YWxpZCBSZXF1ZXN0IE1ldGhvZFwiIH0pO1xyXG4gIH1cclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IHJlZ2lzdGVyQ29udHJvbGxlcjtcclxuIl0sIm5hbWVzIjpbIlVzZXIiLCJiY3J5cHQiLCJkYkNvbm5lY3QiLCJyZWdpc3RlckNvbnRyb2xsZXIiLCJyZXEiLCJyZXMiLCJjb25zb2xlIiwibG9nIiwiYm9keSIsIm1ldGhvZCIsInVzZXJOYW1lIiwiZW1haWwiLCJwYXNzd29yZCIsInN0YXR1cyIsImpzb24iLCJtZXNzYWdlIiwiaXNFbWFpbEV4aXN0cyIsImZpbmRPbmUiLCJleGVjIiwiaGFzaGVkUGFzc3dvcmQiLCJoYXNoIiwibmV3VXNlciIsInJlc3VsdCIsInNhdmUiLCJlcnIiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./pages/api/user/register.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/user/register.js"));
module.exports = __webpack_exports__;

})();