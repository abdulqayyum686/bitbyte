"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/user/get-current-user/[userId]";
exports.ids = ["pages/api/user/get-current-user/[userId]"];
exports.modules = {

/***/ "mongoose":
/*!***************************!*\
  !*** external "mongoose" ***!
  \***************************/
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ "(api)/./config/dbConnect.js":
/*!*****************************!*\
  !*** ./config/dbConnect.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mongoose */ \"mongoose\");\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);\n\nconst MONGO_URL = process.env.DATABASE_URI;\nif (!MONGO_URL) {\n    throw new Error(\"Please define the MONGO_URL environment variable inside .env.local\");\n}\nconsole.log(MONGO_URL);\nasync function dbConnect() {\n    const con = await mongoose__WEBPACK_IMPORTED_MODULE_0___default().connect(MONGO_URL);\n    return con;\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (dbConnect);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9jb25maWcvZGJDb25uZWN0LmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7OztBQUFnQztBQUNoQyxNQUFNQyxZQUFZQyxRQUFRQyxHQUFHLENBQUNDLFlBQVk7QUFFMUMsSUFBSSxDQUFDSCxXQUFXO0lBQ2QsTUFBTSxJQUFJSSxNQUNSLHNFQUNBO0FBQ0osQ0FBQztBQUNEQyxRQUFRQyxHQUFHLENBQUNOO0FBQ1osZUFBZU8sWUFBWTtJQUN6QixNQUFNQyxNQUFNLE1BQU1ULHVEQUFnQixDQUNoQ0M7SUFFRixPQUFPUTtBQUNUO0FBRUEsaUVBQWVELFNBQVNBLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9ib29rc2xpYnJhcnkvLi9jb25maWcvZGJDb25uZWN0LmpzPzc3OWEiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IG1vbmdvb3NlIGZyb20gXCJtb25nb29zZVwiO1xyXG5jb25zdCBNT05HT19VUkwgPSBwcm9jZXNzLmVudi5EQVRBQkFTRV9VUkk7XHJcblxyXG5pZiAoIU1PTkdPX1VSTCkge1xyXG4gIHRocm93IG5ldyBFcnJvcihcclxuICAgIFwiUGxlYXNlIGRlZmluZSB0aGUgTU9OR09fVVJMIGVudmlyb25tZW50IHZhcmlhYmxlIGluc2lkZSAuZW52LmxvY2FsXCJcclxuICApO1xyXG59XHJcbmNvbnNvbGUubG9nKE1PTkdPX1VSTCk7XHJcbmFzeW5jIGZ1bmN0aW9uIGRiQ29ubmVjdCgpIHtcclxuICBjb25zdCBjb24gPSBhd2FpdCBtb25nb29zZS5jb25uZWN0KFxyXG4gICAgTU9OR09fVVJMXHJcbiAgKTtcclxuICByZXR1cm4gY29uO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBkYkNvbm5lY3Q7XHJcbiJdLCJuYW1lcyI6WyJtb25nb29zZSIsIk1PTkdPX1VSTCIsInByb2Nlc3MiLCJlbnYiLCJEQVRBQkFTRV9VUkkiLCJFcnJvciIsImNvbnNvbGUiLCJsb2ciLCJkYkNvbm5lY3QiLCJjb24iLCJjb25uZWN0Il0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./config/dbConnect.js\n");

/***/ }),

/***/ "(api)/./models/User.js":
/*!************************!*\
  !*** ./models/User.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mongoose */ \"mongoose\");\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);\n\nconst userSchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({\n    userName: {\n        type: String,\n        required: true\n    },\n    email: {\n        type: String,\n        required: true\n    },\n    password: String\n}, {\n    timestamps: true\n});\nif ((mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.User)) {\n    delete (mongoose__WEBPACK_IMPORTED_MODULE_0___default().connection.models.User);\n}\nconst userModel = mongoose__WEBPACK_IMPORTED_MODULE_0___default().model(\"User\", userSchema);\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (userModel);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9tb2RlbHMvVXNlci5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7QUFBZ0M7QUFFaEMsTUFBTUMsYUFBYSxJQUFJRCx3REFBZSxDQUNwQztJQUNFRyxVQUFVO1FBQ1JDLE1BQU1DO1FBQ05DLFVBQVUsSUFBSTtJQUNoQjtJQUNBQyxPQUFPO1FBQ0xILE1BQU1DO1FBQ05DLFVBQVUsSUFBSTtJQUNoQjtJQUNBRSxVQUFVSDtBQUNaLEdBQ0E7SUFDRUksWUFBWSxJQUFJO0FBQ2xCO0FBR0YsSUFBSVQsNkRBQW9CLEVBQUU7SUFDeEIsT0FBT0Esd0VBQWtDO0FBQzNDLENBQUM7QUFFRCxNQUFNYSxZQUFZYixxREFBYyxDQUFDLFFBQVFDO0FBRXpDLGlFQUFlWSxTQUFTQSxFQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vYm9va3NsaWJyYXJ5Ly4vbW9kZWxzL1VzZXIuanM/NzM2NyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgbW9uZ29vc2UgZnJvbSBcIm1vbmdvb3NlXCI7XHJcblxyXG5jb25zdCB1c2VyU2NoZW1hID0gbmV3IG1vbmdvb3NlLlNjaGVtYShcclxuICB7XHJcbiAgICB1c2VyTmFtZToge1xyXG4gICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgIHJlcXVpcmVkOiB0cnVlLFxyXG4gICAgfSxcclxuICAgIGVtYWlsOiB7XHJcbiAgICAgIHR5cGU6IFN0cmluZyxcclxuICAgICAgcmVxdWlyZWQ6IHRydWUsXHJcbiAgICB9LFxyXG4gICAgcGFzc3dvcmQ6IFN0cmluZyxcclxuICB9LFxyXG4gIHtcclxuICAgIHRpbWVzdGFtcHM6IHRydWUsXHJcbiAgfVxyXG4pO1xyXG5cclxuaWYgKG1vbmdvb3NlLm1vZGVscy5Vc2VyKSB7XHJcbiAgZGVsZXRlIG1vbmdvb3NlLmNvbm5lY3Rpb24ubW9kZWxzW1wiVXNlclwiXTtcclxufVxyXG5cclxuY29uc3QgdXNlck1vZGVsID0gbW9uZ29vc2UubW9kZWwoXCJVc2VyXCIsIHVzZXJTY2hlbWEpO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgdXNlck1vZGVsO1xyXG4iXSwibmFtZXMiOlsibW9uZ29vc2UiLCJ1c2VyU2NoZW1hIiwiU2NoZW1hIiwidXNlck5hbWUiLCJ0eXBlIiwiU3RyaW5nIiwicmVxdWlyZWQiLCJlbWFpbCIsInBhc3N3b3JkIiwidGltZXN0YW1wcyIsIm1vZGVscyIsIlVzZXIiLCJjb25uZWN0aW9uIiwidXNlck1vZGVsIiwibW9kZWwiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./models/User.js\n");

/***/ }),

/***/ "(api)/./pages/api/user/get-current-user/[userId].js":
/*!*****************************************************!*\
  !*** ./pages/api/user/get-current-user/[userId].js ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _models_User__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./../../../../models/User */ \"(api)/./models/User.js\");\n/* harmony import */ var _config_dbConnect__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../../../config/dbConnect */ \"(api)/./config/dbConnect.js\");\n\n\nconst registerController = async (req, res)=>{\n    console.log(req.body);\n    await (0,_config_dbConnect__WEBPACK_IMPORTED_MODULE_1__[\"default\"])();\n    if (req.method === \"GET\") {\n        try {\n            console.log(req.query);\n            const result = await _models_User__WEBPACK_IMPORTED_MODULE_0__[\"default\"].findOne({\n                _id: req.query.userId\n            }).exec();\n            res.status(201).json({\n                result\n            });\n        } catch (err) {\n            console.log(err);\n            res.status(500).json({\n                message: \"Something went Wrong, Internal Server Error!\"\n            });\n        }\n    } else {\n        return res.status(404).json({\n            message: \"Invalid Request Method\"\n        });\n    }\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (registerController);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvdXNlci9nZXQtY3VycmVudC11c2VyL1t1c2VySWRdLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7OztBQUE2QztBQUNVO0FBQ3ZELE1BQU1FLHFCQUFxQixPQUFPQyxLQUFLQyxNQUFRO0lBQzdDQyxRQUFRQyxHQUFHLENBQUNILElBQUlJLElBQUk7SUFDcEIsTUFBTU4sNkRBQVNBO0lBRWYsSUFBSUUsSUFBSUssTUFBTSxLQUFLLE9BQU87UUFDeEIsSUFBSTtZQUNGSCxRQUFRQyxHQUFHLENBQUNILElBQUlNLEtBQUs7WUFDckIsTUFBTUMsU0FBUyxNQUFNViw0REFBWSxDQUFDO2dCQUFFWSxLQUFLVCxJQUFJTSxLQUFLLENBQUNJLE1BQU07WUFBQyxHQUFHQyxJQUFJO1lBQ2pFVixJQUFJVyxNQUFNLENBQUMsS0FBS0MsSUFBSSxDQUFDO2dCQUNuQk47WUFDRjtRQUNGLEVBQUUsT0FBT08sS0FBSztZQUNaWixRQUFRQyxHQUFHLENBQUNXO1lBQ1piLElBQUlXLE1BQU0sQ0FBQyxLQUFLQyxJQUFJLENBQUM7Z0JBQ25CRSxTQUFTO1lBQ1g7UUFDRjtJQUNGLE9BQU87UUFDTCxPQUFPZCxJQUFJVyxNQUFNLENBQUMsS0FBS0MsSUFBSSxDQUFDO1lBQUVFLFNBQVM7UUFBeUI7SUFDbEUsQ0FBQztBQUNIO0FBRUEsaUVBQWVoQixrQkFBa0JBLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9ib29rc2xpYnJhcnkvLi9wYWdlcy9hcGkvdXNlci9nZXQtY3VycmVudC11c2VyL1t1c2VySWRdLmpzPzc2MzAiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFVzZXIgZnJvbSBcIi4vLi4vLi4vLi4vLi4vbW9kZWxzL1VzZXJcIjtcclxuaW1wb3J0IGRiQ29ubmVjdCBmcm9tIFwiLi8uLi8uLi8uLi8uLi9jb25maWcvZGJDb25uZWN0XCI7XHJcbmNvbnN0IHJlZ2lzdGVyQ29udHJvbGxlciA9IGFzeW5jIChyZXEsIHJlcykgPT4ge1xyXG4gIGNvbnNvbGUubG9nKHJlcS5ib2R5KTtcclxuICBhd2FpdCBkYkNvbm5lY3QoKTtcclxuXHJcbiAgaWYgKHJlcS5tZXRob2QgPT09IFwiR0VUXCIpIHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnNvbGUubG9nKHJlcS5xdWVyeSk7XHJcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IFVzZXIuZmluZE9uZSh7IF9pZDogcmVxLnF1ZXJ5LnVzZXJJZCB9KS5leGVjKCk7XHJcbiAgICAgIHJlcy5zdGF0dXMoMjAxKS5qc29uKHtcclxuICAgICAgICByZXN1bHQsXHJcbiAgICAgIH0pO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUubG9nKGVycik7XHJcbiAgICAgIHJlcy5zdGF0dXMoNTAwKS5qc29uKHtcclxuICAgICAgICBtZXNzYWdlOiBcIlNvbWV0aGluZyB3ZW50IFdyb25nLCBJbnRlcm5hbCBTZXJ2ZXIgRXJyb3IhXCIsXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH0gZWxzZSB7XHJcbiAgICByZXR1cm4gcmVzLnN0YXR1cyg0MDQpLmpzb24oeyBtZXNzYWdlOiBcIkludmFsaWQgUmVxdWVzdCBNZXRob2RcIiB9KTtcclxuICB9XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCByZWdpc3RlckNvbnRyb2xsZXI7XHJcbiJdLCJuYW1lcyI6WyJVc2VyIiwiZGJDb25uZWN0IiwicmVnaXN0ZXJDb250cm9sbGVyIiwicmVxIiwicmVzIiwiY29uc29sZSIsImxvZyIsImJvZHkiLCJtZXRob2QiLCJxdWVyeSIsInJlc3VsdCIsImZpbmRPbmUiLCJfaWQiLCJ1c2VySWQiLCJleGVjIiwic3RhdHVzIiwianNvbiIsImVyciIsIm1lc3NhZ2UiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./pages/api/user/get-current-user/[userId].js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/user/get-current-user/[userId].js"));
module.exports = __webpack_exports__;

})();