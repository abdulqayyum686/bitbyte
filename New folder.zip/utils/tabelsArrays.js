export const Array = [
  { title: "Title" },
  { title: "Author Name" },
  { title: "Publication House" },
  { title: "Publication Date" },
  { title: "Publication year" },
  { title: "Genre" },
  { title: "Status" },
  { title: "Change Book status" },
  { title: "Edit" },
  { title: "Delete" },
];
