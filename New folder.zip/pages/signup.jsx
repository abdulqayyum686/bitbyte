import React from "react";
import UserSignUp from "../components/registerForm";

const SignUp = () => {
  return (
    <>
      <div>
        <UserSignUp />
      </div>
    </>
  );
};

export default SignUp;
