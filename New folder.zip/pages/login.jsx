import Header from "@/components/Header";
import React from "react";
import UserLogin from "../components/loginForm";

const Login = () => {
  return (
    <>
      <div>
        <UserLogin />
      </div>
    </>
  );
};

export default Login;
