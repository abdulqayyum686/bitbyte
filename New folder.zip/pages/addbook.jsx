import AddBook from "@/components/AddBook";
import Header from "@/components/Header";
import React from "react";

const Addbook = () => {
  return (
    <div>
    <Header/>
      <AddBook />
    </div>
  );
};

export default Addbook;
